package Week4;

public class Warehouse {

}
